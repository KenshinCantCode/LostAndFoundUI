<?php
class Database {
    private $conn;

    private function loadEnvironment() {
        static $loaded = false;
        if ($loaded) {
            return;
        }
        $loaded = true;

        $envPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
        if (!is_file($envPath)) {
            return;
        }

        $lines = file($envPath, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            throw new RuntimeException('The .env file exists but cannot be read.');
        }

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }

            $separator = strpos($line, '=');
            if ($separator === false) {
                throw new RuntimeException('Invalid .env entry: expected KEY=value.');
            }

            $key = trim(substr($line, 0, $separator));
            $value = trim(substr($line, $separator + 1));
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key)) {
                throw new RuntimeException('Invalid environment variable name in .env.');
            }

            if (strlen($value) >= 2) {
                $first = $value[0];
                $last = substr($value, -1);
                if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                    $value = substr($value, 1, -1);
                }
            }

            if (getenv($key) === false) {
                putenv($key . '=' . $value);
            }
        }
    }

    public function getConnection() {
        $this->conn = null;
        try {
            $this->loadEnvironment();

            $localConfigPath = __DIR__ . '/database.local.php';
            $localConfig = is_file($localConfigPath) ? require $localConfigPath : [];
            if (!is_array($localConfig)) {
                throw new RuntimeException('Local database configuration must return an array.');
            }

            $host = getenv('DB_HOST') ?: ($localConfig['host'] ?? 'sql306.infinityfree.com');
            $dbname = getenv('DB_NAME') ?: ($localConfig['name'] ?? 'if0_43135706_lost_found_db');
            $username = getenv('DB_USER') ?: ($localConfig['username'] ?? 'if0_43135706');
            $password = getenv('DB_PASSWORD');
            $password = $password === false ? ($localConfig['password'] ?? 'kenshin091306') : $password;

            $this->conn = new PDO(
                "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
            $this->conn->exec("SET time_zone = '+08:00'");
        } catch(Throwable $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            echo 'Database connection failed. Check the database settings and server error log.';
        }
        return $this->conn;
    }
}
